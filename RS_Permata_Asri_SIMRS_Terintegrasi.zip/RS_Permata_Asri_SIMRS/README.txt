RS PERMATA ASRI — SIMRS TERINTEGRASI
====================================

Cara menjalankan
----------------
1. Ekstrak ZIP.
2. Buka file index.html.
3. Tidak membutuhkan server, database, atau internet.

Akun demo
---------
Administrator SIMRS
- username: novella
- password: permata123

Administrator TI
- username: admin.ti
- password: ti123

Bidang Pelayanan Medis
- username: pelayanan
- password: medis123

Dokter / DPJP
- username: dokter
- password: dokter123

Perawat / PPA
- username: perawat
- password: perawat123

Perawat IGD / Triage
- username: triage
- password: triage123

Admisi Rawat Inap
- username: admisi
- password: admisi123

Laboratorium / ATLM
- username: lab
- password: lab123

Farmasi / Apoteker
- username: farmasi
- password: farmasi123

Radiografer
- username: radiologi
- password: rad123

Petugas Gudang
- username: gudang
- password: gudang123

Kasir / Billing
- username: kasir
- password: kasir123

Petugas Rekam Medis
- username: rekammedis
- password: rm123

Catatan
-------
Website ini adalah prototype front-end untuk tugas SIMRS. Authentication dan RBAC
disimulasikan di browser menggunakan localStorage. Pada sistem produksi, pengecekan
authorization tetap harus dilakukan di sisi server/backend untuk setiap request.

Modul yang digabung
-------------------
- User & Access Management
- Master Data & Configuration
- EMR
- CPOE / Order Management
- Laboratory
- IGD
- Rawat Inap
- Nursing
- Farmasi
- Radiologi
- Inventori / Stok Gudang
- Billing / Kasir
- Reporting
- Audit Log
