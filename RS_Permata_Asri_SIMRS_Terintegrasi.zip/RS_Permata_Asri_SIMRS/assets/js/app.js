const APP_KEY = 'rs-permata-asri-session-v1';
const DATA_KEY = 'rs-permata-asri-data-v1';

const USERS = [
  {
    username: 'novella',
    password: 'permata123',
    name: 'Novella',
    role: 'admin_simrs',
    roleLabel: 'Administrator SIMRS',
    initials: 'AS'
  },
  {
    username: 'admin.ti',
    password: 'ti123',
    name: 'Novella',
    role: 'admin_ti',
    roleLabel: 'Administrator TI',
    initials: 'IT'
  },
  {
    username: 'pelayanan',
    password: 'medis123',
    name: 'Novella',
    role: 'pelayanan_medis',
    roleLabel: 'Bidang Pelayanan Medis',
    initials: 'PM'
  },
  {
    username: 'dokter',
    password: 'dokter123',
    name: 'dr. Andi Pratama',
    role: 'dokter',
    roleLabel: 'Dokter / DPJP',
    initials: 'AP'
  },
  {
    username: 'perawat',
    password: 'perawat123',
    name: 'Ns. Intan Permata, S.Kep',
    role: 'perawat',
    roleLabel: 'Perawat / PPA',
    initials: 'IP'
  },
  {
    username: 'triage',
    password: 'triage123',
    name: 'Ns. Rani Puspita, S.Kep',
    role: 'igd',
    roleLabel: 'Perawat IGD / Triage',
    initials: 'RP'
  },
  {
    username: 'admisi',
    password: 'admisi123',
    name: 'Rika Andriani, A.Md.Kes',
    role: 'admisi',
    roleLabel: 'Admisi Rawat Inap',
    initials: 'RA'
  },
  {
    username: 'lab',
    password: 'lab123',
    name: 'Analis Laboratorium',
    role: 'lab',
    roleLabel: 'Laboratorium / ATLM',
    initials: 'LA'
  },
  {
    username: 'farmasi',
    password: 'farmasi123',
    name: 'apt. Nadia Kirana, S.Farm',
    role: 'farmasi',
    roleLabel: 'Farmasi / Apoteker',
    initials: 'NK'
  },
  {
    username: 'radiologi',
    password: 'rad123',
    name: 'Kakitangan Radiologi',
    role: 'radiologi',
    roleLabel: 'Radiografer',
    initials: 'RG'
  },
  {
    username: 'gudang',
    password: 'gudang123',
    name: 'Pegawai Logistik',
    role: 'gudang',
    roleLabel: 'Petugas Gudang',
    initials: 'LG'
  },
  {
    username: 'kasir',
    password: 'kasir123',
    name: 'Dimas Nugroho, S.E.',
    role: 'kasir',
    roleLabel: 'Petugas Kasir / Billing',
    initials: 'DN'
  },
  {
    username: 'rekammedis',
    password: 'rm123',
    name: 'Petugas Rekam Medis',
    role: 'rekammedis',
    roleLabel: 'Petugas Rekam Medis',
    initials: 'RM'
  }
];

const MENU = [
  { id: 'dashboard', label: 'Dashboard', icon: '⌂', section: 'NAVIGASI' },

  { id: 'user-access', label: 'User & Hak Akses', icon: '♙', section: 'MASTER DATA' },
  { id: 'master-doctor', label: 'Data Dokter', icon: '♟', section: 'MASTER DATA' },
  { id: 'master-unit', label: 'Poli & Ruangan', icon: '▦', section: 'MASTER DATA' },
  { id: 'master-tarif', label: 'Tarif', icon: 'Rp', section: 'MASTER DATA' },
  { id: 'master-icd', label: 'ICD-10', icon: 'ICD', section: 'MASTER DATA' },
  { id: 'master-drug', label: 'Obat', icon: '+', section: 'MASTER DATA' },
  { id: 'master-lab', label: 'Laboratorium', icon: '⌁', section: 'MASTER DATA' },

  { id: 'emr', label: 'Electronic Medical Record', icon: '▣', section: 'PELAYANAN' },
  { id: 'cpoe', label: 'CPOE / Order Management', icon: '+', section: 'PELAYANAN' },
  { id: 'laboratory', label: 'Laboratory', icon: '⌁', section: 'PELAYANAN' },
  { id: 'igd', label: 'IGD', icon: '✚', section: 'PELAYANAN' },
  { id: 'inpatient', label: 'Rawat Inap', icon: '▤', section: 'PELAYANAN' },
  { id: 'nursing', label: 'Nursing', icon: '♥', section: 'PELAYANAN' },
  { id: 'pharmacy', label: 'Farmasi', icon: 'Rx', section: 'PELAYANAN' },
  { id: 'radiology', label: 'Radiologi', icon: '◫', section: 'PELAYANAN' },
  { id: 'inventory', label: 'Stok Gudang', icon: '▥', section: 'PELAYANAN' },
  { id: 'billing', label: 'Kasir & Pembayaran', icon: 'Rp', section: 'PELAYANAN' },

  { id: 'reporting', label: 'Laporan Operasional', icon: '▧', section: 'REPORTING' },
  { id: 'monthly', label: 'Laporan Bulanan', icon: '▤', section: 'REPORTING' },
  { id: 'audit', label: 'Audit Log', icon: '◉', section: 'SYSTEM' }
];

const PERMISSIONS = {
  admin_simrs: MENU.map(item => item.id),

  admin_ti: [
    'dashboard',
    'user-access',
    'master-doctor',
    'master-unit',
    'master-tarif',
    'master-icd',
    'master-drug',
    'master-lab',
    'reporting',
    'monthly',
    'audit'
  ],

  pelayanan_medis: [
    'dashboard',
    'emr',
    'cpoe',
    'laboratory',
    'igd',
    'inpatient',
    'nursing',
    'pharmacy',
    'radiology',
    'reporting',
    'monthly'
  ],

  dokter: [
    'dashboard',
    'emr',
    'cpoe',
    'laboratory',
    'radiology',
    'inpatient',
    'nursing',
    'reporting'
  ],

  perawat: [
    'dashboard',
    'emr',
    'nursing',
    'inpatient',
    'cpoe',
    'reporting'
  ],

  igd: [
    'dashboard',
    'igd',
    'emr',
    'cpoe'
  ],

  admisi: [
    'dashboard',
    'inpatient',
    'billing'
  ],

  lab: [
    'dashboard',
    'laboratory',
    'master-lab',
    'emr',
    'reporting'
  ],

  farmasi: [
    'dashboard',
    'pharmacy',
    'master-drug',
    'cpoe',
    'inventory'
  ],

  radiologi: [
    'dashboard',
    'radiology',
    'cpoe',
    'emr'
  ],

  gudang: [
    'dashboard',
    'inventory',
    'master-drug'
  ],

  kasir: [
    'dashboard',
    'billing',
    'inpatient',
    'reporting'
  ],

  rekammedis: [
    'dashboard',
    'emr',
    'master-doctor',
    'master-unit',
    'master-icd',
    'reporting',
    'audit'
  ]
};

const DEFAULT_DATA = {
  billing: [
    { no: 'BL-001', rm: 'RM-1001', patient: 'Budi Santoso', service: 'Poli Umum + Pemeriksaan Lab', total: 250000, method: 'Transfer Bank', status: 'Lunas' },
    { no: 'BL-002', rm: 'RM-1002', patient: 'Siti Aminah', service: 'Poli Anak + Resep Obat', total: 175000, method: 'BPJS Kesehatan', status: 'Lunas' },
    { no: 'BL-003', rm: 'RM-1003', patient: 'Hendra Cipta', service: 'Instalasi Radiologi (Thorax)', total: 450000, method: 'Belum Dipilih', status: 'Belum Lunas' },
    { no: 'BL-004', rm: 'RM-1126', patient: 'Benjamin Rashad', service: 'Poli IGD', total: 500000, method: 'QRIS / E-Wallet', status: 'Lunas' },
    { no: 'BL-005', rm: 'RM-1902', patient: 'Sarah Wijayanto', service: 'Rawat Inap', total: 5000000, method: 'BPJS / Asuransi', status: 'Lunas' }
  ],
  prescriptions: [
    { id: 'RSP-101', patient: 'Budi Santoso', drug: 'Paracetamol 500 mg', dose: '3x sehari', status: 'Diproses' },
    { id: 'RSP-102', patient: 'Siti Aminah', drug: 'Sirap Sanmol', dose: '2x sehari', status: 'Selesai' }
  ],
  radiology: [
    { no: 'RAD-106', patient: 'Hendra Cipta', exam: 'MRI Kepala', status: 'Menunggu' },
    { no: 'RAD-484', patient: 'Rina Melati', exam: 'USG Pelvis', status: 'Selesai (PACS)' },
    { no: 'RAD-081', patient: 'Agus Supriyadi', exam: 'Rontgen Thorax', status: 'Menunggu' },
    { no: 'RAD-002', patient: 'Dewi Lestari', exam: 'USG Abdomen', status: 'Selesai (PACS)' }
  ],
  inventory: [
    { code: 'INV-001', item: 'Paracetamol 500 mg', category: 'Medis', location: 'Depo Farmasi Utama', stock: 350 },
    { code: 'INV-002', item: 'Hand Sanitizer 200 ml', category: 'Non-Medis', location: 'Gudang Utama', stock: 100 },
    { code: 'INV-003', item: 'Ceftriaxone 1 g', category: 'Medis', location: 'Depo Bangsal', stock: 24 },
    { code: 'INV-004', item: 'Kertas A4', category: 'Non-Medis', location: 'Gudang Umum', stock: 120 }
  ],
  audit: [
    { time: '08:14', user: 'Novella', action: 'Login berhasil', module: 'Authentication' },
    { time: '08:31', user: 'dr. Andi Pratama', action: 'Membuka EMR RM-000123', module: 'EMR' },
    { time: '08:42', user: 'Analis Laboratorium', action: 'Validasi hasil LAB-2026-0919', module: 'Laboratory' },
    { time: '08:55', user: 'Dimas Nugroho', action: 'Closing pembayaran BL-004', module: 'Billing' }
  ]
};

function getData() {
  const saved = localStorage.getItem(DATA_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (error) {
      console.warn('Data lokal rusak. Menggunakan data awal.', error);
    }
  }

  localStorage.setItem(DATA_KEY, JSON.stringify(DEFAULT_DATA));
  return structuredClone(DEFAULT_DATA);
}

function saveData(data) {
  localStorage.setItem(DATA_KEY, JSON.stringify(data));
}

function getSession() {
  const raw = localStorage.getItem(APP_KEY);
  if (!raw) return null;

  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function setSession(user) {
  localStorage.setItem(APP_KEY, JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem(APP_KEY);
}

function money(value) {
  return 'Rp ' + Number(value).toLocaleString('id-ID');
}

function badge(text, color = 'blue') {
  return `<span class="badge ${color}">${text}</span>`;
}

function allowed(user, page) {
  return Boolean(PERMISSIONS[user.role]?.includes(page));
}

function loginView() {
  return `
    <div class="login-shell">
      <div class="login-card">
        <div class="brand-row">
          <div class="brand-mark">✚</div>
          <div>
            <div class="brand-name">RS Permata Asri</div>
            <div class="brand-sub">Sistem Informasi Manajemen Rumah Sakit</div>
          </div>
        </div>

        <h1>Akses Sistem</h1>
        <p>Masukkan kredensial akun Anda sesuai peran.</p>

        <form id="loginForm">
          <div class="form-group">
            <label class="form-label" for="username">Username</label>
            <input class="form-control" id="username" name="username" autocomplete="username" placeholder="Masukkan username">
          </div>

          <div class="form-group">
            <label class="form-label" for="password">Password</label>
            <input class="form-control" id="password" name="password" type="password" autocomplete="current-password" placeholder="Masukkan password">
          </div>

          <div class="form-group">
            <label class="form-label" for="role">Role</label>
            <select class="form-control" id="role" name="role">
              <option value="">Pilih role</option>
              ${USERS.map(user => `<option value="${user.role}">${user.roleLabel}</option>`).join('')}
            </select>
          </div>

          <div class="login-actions">
            <button class="btn btn-primary" type="submit">Masuk ke SIMRS</button>
            <button class="btn btn-secondary" type="button" id="cancelLogin">Batal</button>
          </div>
        </form>

        <div class="demo-box">
          <strong>Akun demo per role</strong>
          <small>Klik akun untuk mengisi form otomatis, lalu tekan Masuk.</small>

          <div class="demo-grid">
            ${USERS.slice(0, 8).map(user => `
              <button class="demo-account" type="button" data-demo="${user.username}">
                <b>${user.roleLabel}</b>
                <span>${user.username} / ${user.password}</span>
              </button>
            `).join('')}
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderLogin() {
  document.getElementById('app').innerHTML = loginView();

  const form = document.getElementById('loginForm');

  document.querySelectorAll('[data-demo]').forEach(button => {
    button.addEventListener('click', () => {
      const user = USERS.find(item => item.username === button.dataset.demo);
      if (!user) return;

      document.getElementById('username').value = user.username;
      document.getElementById('password').value = user.password;
      document.getElementById('role').value = user.role;
    });
  });

  document.getElementById('cancelLogin').addEventListener('click', () => {
    form.reset();
  });

  form.addEventListener('submit', event => {
    event.preventDefault();

    const username = form.username.value.trim();
    const password = form.password.value;
    const role = form.role.value;

    const user = USERS.find(item =>
      item.username === username &&
      item.password === password &&
      item.role === role
    );

    if (!user) {
      toast('Username, password, atau role tidak sesuai.');
      return;
    }

    setSession(user);
    renderApp(user, 'dashboard');
  });
}

function sidebar(user, activePage) {
  const visible = MENU.filter(item => allowed(user, item.id));
  let lastSection = null;

  return `
    <aside class="sidebar">
      <div class="sidebar-brand">
        <div class="brand-mark">✚</div>
        <div>
          <strong>RS Permata Asri</strong>
          <small>SIMRS Terintegrasi</small>
        </div>
      </div>

      <div class="role-card">
        <b>${user.name}</b>
        <span>${user.roleLabel}</span>
      </div>

      <nav>
        ${visible.map(item => {
          const section = item.section !== lastSection
            ? `<div class="nav-section-title">${item.section}</div>`
            : '';

          lastSection = item.section;

          return `
            ${section}
            <button
              class="nav-item ${activePage === item.id ? 'active' : ''}"
              data-page="${item.id}"
            >
              <span class="nav-icon">${item.icon}</span>
              <span>${item.label}</span>
            </button>
          `;
        }).join('')}
      </nav>

      <div class="sidebar-footer">
        <button class="logout-btn" id="logoutButton">← Keluar</button>
      </div>
    </aside>
  `;
}

function topbar(user, pageLabel) {
  return `
    <header class="topbar">
      <div class="breadcrumb">SIMRS / ${pageLabel}</div>

      <div class="user-panel">
        <div class="user-text">
          <strong>${user.name}</strong>
          <span>${user.roleLabel}</span>
        </div>

        <div class="avatar">${user.initials}</div>
      </div>
    </header>
  `;
}

function pageLabel(pageId) {
  return MENU.find(item => item.id === pageId)?.label || 'Dashboard';
}

function renderApp(user, page = 'dashboard') {
  if (!allowed(user, page)) {
    page = 'dashboard';
  }

  document.getElementById('app').innerHTML = `
    <div class="app-shell">
      ${sidebar(user, page)}

      <main class="main">
        ${topbar(user, pageLabel(page))}
        <div class="content" id="pageContent"></div>
      </main>
    </div>
  `;

  document.querySelectorAll('[data-page]').forEach(button => {
    button.addEventListener('click', () => {
      renderApp(user, button.dataset.page);
    });
  });

  document.getElementById('logoutButton').addEventListener('click', () => {
    clearSession();
    renderLogin();
  });

  renderPage(user, page);
}

function renderPage(user, page) {
  const pages = {
    dashboard: dashboardPage,
    'user-access': userAccessPage,
    'master-doctor': masterDoctorPage,
    'master-unit': masterUnitPage,
    'master-tarif': masterTarifPage,
    'master-icd': masterIcdPage,
    'master-drug': masterDrugPage,
    'master-lab': masterLabPage,
    emr: emrPage,
    cpoe: cpoePage,
    laboratory: laboratoryPage,
    igd: igdPage,
    inpatient: inpatientPage,
    nursing: nursingPage,
    pharmacy: pharmacyPage,
    radiology: radiologyPage,
    inventory: inventoryPage,
    billing: billingPage,
    reporting: reportingPage,
    monthly: monthlyPage,
    audit: auditPage
  };

  const renderer = pages[page] || dashboardPage;
  document.getElementById('pageContent').innerHTML = renderer(user);
  bindPageActions(user, page);
}

function dashboardPage(user) {
  const quickModules = MENU
    .filter(item => item.section === 'PELAYANAN' && allowed(user, item.id))
    .slice(0, 8);

  return `
    <div class="page-header">
      <h1>Tinjauan Rumah Sakit</h1>
      <p>Ringkasan operasional dan akses cepat sesuai role ${user.roleLabel}.</p>
    </div>

    <div class="grid grid-4">
      <div class="card metric-card">
        <label>Pasien Dirawat</label>
        <strong>342</strong>
        <div class="metric-icon">▤</div>
      </div>

      <div class="card metric-card">
        <label>Antrean Poliklinik</label>
        <strong>128</strong>
        <div class="metric-icon" style="background:#fff2e5;color:#e7892f;">♟</div>
      </div>

      <div class="card metric-card">
        <label>Dokter Aktif</label>
        <strong>45</strong>
        <div class="metric-icon" style="background:#eafaf1;color:#20a76b;">♙</div>
      </div>

      <div class="card metric-card">
        <label>Kamar Tersedia</label>
        <strong>14</strong>
        <div class="metric-icon" style="background:#f3edff;color:#7a61e7;">▣</div>
      </div>
    </div>

    <div class="section-title" style="margin-top:24px;">
      <div>
        <h2>Modul yang dapat diakses</h2>
        <p>Menu tampil dinamis berdasarkan role yang sedang login.</p>
      </div>
    </div>

    <div class="module-launcher">
      ${quickModules.map(item => `
        <div class="module-tile" data-open-page="${item.id}">
          <div class="tile-icon">${item.icon}</div>
          <strong>${item.label}</strong>
          <small>Buka modul ${item.label} sesuai hak akses saat ini.</small>
        </div>
      `).join('')}
    </div>
  `;
}

function userAccessPage() {
  return `
    <div class="page-header">
      <h1>Pembuatan Akun User dan Hak Akses</h1>
      <p>Kelola permintaan pembuatan akun dan perubahan hak akses pengguna.</p>
    </div>

    <div class="grid grid-4">
      ${[
        ['Total Permintaan', '4', 'blue'],
        ['Menunggu', '0', 'orange'],
        ['Disetujui', '3', 'green'],
        ['Ditolak', '1', 'red']
      ].map(([label, value, color]) => `
        <div class="card metric-card">
          <label>${label}</label>
          <strong>${value}</strong>
          <div class="metric-icon">${color === 'green' ? '✓' : color === 'red' ? '×' : color === 'orange' ? '!' : '▣'}</div>
        </div>
      `).join('')}
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="section-title">
        <div>
          <h2>Daftar Permintaan</h2>
          <p>Request akun baru, reset akses, dan perubahan role.</p>
        </div>
        <button class="btn btn-primary" data-modal="user-request">+ Buat Permintaan</button>
      </div>

      <div class="toolbar">
        <input class="form-control" placeholder="Cari ID / nama / unit">
        <select class="form-control">
          <option>Semua status</option>
          <option>Disetujui</option>
          <option>Ditolak</option>
        </select>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama</th>
              <th>Unit</th>
              <th>Jenis</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>REQ-001</td><td>Andi Pradana</td><td>IGD</td><td>Perubahan Role</td><td>${badge('Disetujui', 'green')}</td><td><button class="btn btn-link">Edit</button></td></tr>
            <tr><td>REQ-002</td><td>Jessi</td><td>Rekam Medis</td><td>Hak Akses</td><td>${badge('Disetujui', 'green')}</td><td><button class="btn btn-link">Edit</button></td></tr>
            <tr><td>REQ-003</td><td>Sisca</td><td>IGD</td><td>Reset Akses</td><td>${badge('Ditolak', 'red')}</td><td><button class="btn btn-link">Edit</button></td></tr>
            <tr><td>REQ-004</td><td>Lala</td><td>Instalasi Gawat Darurat</td><td>Akun Baru</td><td>${badge('Disetujui', 'green')}</td><td><button class="btn btn-link">Edit</button></td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function masterDoctorPage() {
  return `
    <div class="page-header">
      <h1>Data Dokter</h1>
      <p>Kelola dan perbarui master dokter SIMRS.</p>
    </div>

    <div class="card">
      <div class="section-title">
        <div>
          <h2>Daftar Data Dokter</h2>
          <p>4 data aktif.</p>
        </div>
        <button class="btn btn-primary" data-modal="doctor">+ Tambah Data</button>
      </div>

      <div class="toolbar">
        <input class="form-control" placeholder="Cari data...">
        <button class="btn btn-secondary">Ekspor CSV</button>
      </div>

      <table>
        <thead><tr><th>Kode</th><th>Nama Dokter</th><th>Spesialisasi</th><th>Poli</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <tr><td>DR001</td><td>dr. Andi Saputra</td><td>Umum</td><td>Poli Umum</td><td>${badge('Aktif','green')}</td><td><button class="btn btn-link">Edit</button></td></tr>
          <tr><td>DR002</td><td>dr. Maya Putri</td><td>Patologi Klinik</td><td>Laboratorium</td><td>${badge('Aktif','green')}</td><td><button class="btn btn-link">Edit</button></td></tr>
          <tr><td>DR003</td><td>dr. Lala</td><td>Anak</td><td>Poli Anak</td><td>${badge('Aktif','green')}</td><td><button class="btn btn-link">Edit</button></td></tr>
          <tr><td>DR004</td><td>dr. Jeno</td><td>Penyakit Dalam</td><td>Poli Penyakit Dalam</td><td>${badge('Aktif','green')}</td><td><button class="btn btn-link">Edit</button></td></tr>
        </tbody>
      </table>
    </div>
  `;
}

function masterUnitPage() {
  return `
    <div class="page-header">
      <h1>Poli & Ruangan</h1>
      <p>Master unit pelayanan, ruangan, kelas, dan kapasitas.</p>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <div class="section-title">
          <h2>Data Poli</h2>
          <button class="btn btn-primary btn-sm" data-modal="unit">+ Tambah Poli</button>
        </div>
        <table>
          <thead><tr><th>Kode</th><th>Nama Poli</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td>PL001</td><td>Poli Umum</td><td>${badge('Aktif','green')}</td></tr>
            <tr><td>PL002</td><td>Poli Anak</td><td>${badge('Aktif','green')}</td></tr>
            <tr><td>PL003</td><td>Poli Penyakit Dalam</td><td>${badge('Aktif','green')}</td></tr>
          </tbody>
        </table>
      </div>

      <div class="card">
        <div class="section-title">
          <h2>Data Ruangan</h2>
          <button class="btn btn-primary btn-sm" data-modal="room">+ Tambah Ruangan</button>
        </div>
        <table>
          <thead><tr><th>Kode</th><th>Ruangan</th><th>Kelas</th><th>Kapasitas</th></tr></thead>
          <tbody>
            <tr><td>RM001</td><td>Anggrek</td><td>Kelas 1</td><td>30</td></tr>
            <tr><td>RM002</td><td>Melati</td><td>VIP</td><td>20</td></tr>
            <tr><td>RM003</td><td>Mawar</td><td>Kelas 2</td><td>24</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function masterTarifPage() {
  return genericMaster(
    'Tarif',
    'Master tarif pelayanan dan tindakan rumah sakit.',
    ['Kode', 'Layanan', 'Kategori', 'Tarif', 'Status'],
    [
      ['TR001', 'Konsultasi Poli Umum', 'Rawat Jalan', 'Rp 100.000', badge('Aktif','green')],
      ['TR002', 'Rontgen Thorax', 'Radiologi', 'Rp 350.000', badge('Aktif','green')],
      ['TR003', 'Darah Lengkap', 'Laboratorium', 'Rp 120.000', badge('Aktif','green')]
    ]
  );
}

function masterIcdPage() {
  return genericMaster(
    'ICD-10',
    'Master diagnosis untuk dokumentasi klinis.',
    ['Kode', 'Diagnosis', 'Kelompok', 'Status'],
    [
      ['J06.9', 'Acute upper respiratory infection, unspecified', 'Respiratory', badge('Aktif','green')],
      ['I10', 'Essential (primary) hypertension', 'Cardiovascular', badge('Aktif','green')],
      ['E11.9', 'Type 2 diabetes mellitus without complications', 'Endocrine', badge('Aktif','green')]
    ]
  );
}

function masterDrugPage() {
  return genericMaster(
    'Obat',
    'Master obat dan sediaan farmasi.',
    ['Kode', 'Nama Obat', 'Sediaan', 'Stok', 'Status'],
    [
      ['OB001', 'Paracetamol 500 mg', 'Tablet', '350', badge('Aktif','green')],
      ['OB002', 'Ceftriaxone 1 g', 'Vial', '24', badge('Aktif','green')],
      ['OB003', 'Salbutamol nebule 2.5 mg', 'Nebule', '8', badge('Menipis','orange')]
    ]
  );
}

function masterLabPage() {
  return genericMaster(
    'Data Laboratorium',
    'Kelola dan perbarui master data pemeriksaan laboratorium.',
    ['Kode', 'Pemeriksaan', 'Kategori', 'Tarif', 'Status'],
    [
      ['LB001', 'Darah Lengkap', 'Hematologi', 'Rp 120.000', badge('Aktif','green')],
      ['LB002', 'Gula Darah Sewaktu', 'Kimia Klinik', 'Rp 65.000', badge('Aktif','green')],
      ['LB003', 'Urinalisis', 'Urinalisis', 'Rp 75.000', badge('Aktif','green')]
    ]
  );
}

function genericMaster(title, subtitle, columns, rows) {
  return `
    <div class="page-header">
      <h1>${title}</h1>
      <p>${subtitle}</p>
    </div>

    <div class="card">
      <div class="section-title">
        <div>
          <h2>Daftar ${title}</h2>
          <p>${rows.length} data.</p>
        </div>
        <button class="btn btn-primary">+ Tambah Data</button>
      </div>

      <div class="toolbar">
        <input class="form-control" placeholder="Cari data...">
        <button class="btn btn-secondary">Ekspor CSV</button>
      </div>

      <table>
        <thead><tr>${columns.map(column => `<th>${column}</th>`).join('')}</tr></thead>
        <tbody>
          ${rows.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function emrPage() {
  return `
    <div class="page-header">
      <h1>Electronic Medical Record (EMR)</h1>
      <p>Dokumentasi klinis pasien, SOAP/CPPT, diagnosis, tindakan, hasil penunjang, dan riwayat kunjungan.</p>
    </div>

    <div class="card" style="margin-bottom:16px;">
      <div class="toolbar" style="margin-bottom:0;">
        <input class="form-control" value="RM-000123" style="flex:1;">
        <button class="btn btn-primary">Cari Pasien</button>
      </div>
    </div>

    <div class="card patient-banner">
      <div>
        <h3>Budi Santoso</h3>
        <small>RM-000123 • Laki-laki • 35 tahun • NIK 3171011205900001</small>
      </div>
      <div class="status-row">
        ${badge('Rawat Jalan','blue')}
        ${badge('Encounter Aktif','green')}
        ${badge('Alergi: Tidak diketahui','orange')}
      </div>
    </div>

    <div class="card">
      <div class="tabbar">
        <button class="tab active">Ringkasan</button>
        <button class="tab">SOAP / CPPT</button>
        <button class="tab">Diagnosis & Tindakan</button>
        <button class="tab">Hasil Penunjang</button>
        <button class="tab">Riwayat</button>
      </div>

      <div class="grid grid-3">
        <div class="mini-kpi">
          <span>Diagnosis Utama</span>
          <b>J06.9 — ISPA akut</b>
          ${badge('Aktif','green')}
        </div>
        <div class="mini-kpi">
          <span>Tanda Vital Terakhir</span>
          <b>TD 120/80 mmHg</b>
          <small>N 80x/menit • RR 18x/menit • T 36,7°C</small>
        </div>
        <div class="mini-kpi">
          <span>Rencana Tindak Lanjut</span>
          <b>Kontrol 3 hari</b>
          ${badge('Terjadwal','green')}
        </div>
      </div>

      <div class="grid grid-2" style="margin-top:16px;">
        <div class="card" style="box-shadow:none;">
          <div class="section-title">
            <h2>SOAP / CPPT terakhir</h2>
            <button class="btn btn-primary btn-sm" data-modal="soap">+ Tambah Catatan</button>
          </div>
          <p style="font-size:12px;"><b>S:</b> Batuk pilek 3 hari, demam ringan.</p>
          <p style="font-size:12px;"><b>O:</b> TD 120/80, N 80, RR 18, T 36,7°C.</p>
          <p style="font-size:12px;"><b>A:</b> ISPA akut.</p>
          <p style="font-size:12px;"><b>P:</b> Terapi simptomatik, edukasi, kontrol 3 hari.</p>
        </div>

        <div class="card" style="box-shadow:none;">
          <div class="section-title">
            <h2>Hasil Pemeriksaan Penunjang</h2>
            <button class="btn btn-secondary btn-sm" data-open-page="laboratory">Buka Laboratory</button>
          </div>
          <table>
            <thead><tr><th>Tanggal</th><th>Pemeriksaan</th><th>Hasil</th><th>Status</th></tr></thead>
            <tbody>
              <tr><td>19/09/2026</td><td>Darah Lengkap</td><td>Hb 13,2; Leukosit 7.800</td><td>${badge('Tervalidasi','green')}</td></tr>
              <tr><td>15/09/2026</td><td>Gula Darah Sewaktu</td><td>108 mg/dL</td><td>${badge('Tervalidasi','green')}</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}

function cpoePage() {
  return `
    <div class="page-header">
      <h1>CPOE / Order Management</h1>
      <p>Input order dokter terintegrasi ke laboratorium, farmasi, radiologi, konsultasi, dan rawat inap.</p>
    </div>

    <div class="grid grid-4">
      ${[
        ['Laboratorium', 'Pemeriksaan darah, kimia klinik, mikrobiologi', 'lab-order', '⌁'],
        ['Obat', 'Medication order / resep elektronik', 'med-order', 'Rx'],
        ['Radiologi', 'Rontgen, CT, MRI, USG', 'rad-order', '◫'],
        ['Rawat Inap', 'Admission order dan bed request', 'admission-order', '▤']
      ].map(([title, desc, modal, icon]) => `
        <div class="module-tile" data-modal="${modal}">
          <div class="tile-icon">${icon}</div>
          <strong>${title}</strong>
          <small>${desc}</small>
        </div>
      `).join('')}
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="section-title">
        <div>
          <h2>Order Aktif</h2>
          <p>Order pasien yang belum selesai seluruhnya.</p>
        </div>
      </div>

      <table>
        <thead><tr><th>Order</th><th>Pasien</th><th>Jenis</th><th>Detail</th><th>Status</th></tr></thead>
        <tbody>
          <tr><td>ORD-2401</td><td>Budi Santoso</td><td>Laboratorium</td><td>Darah Lengkap</td><td>${badge('In Process','orange')}</td></tr>
          <tr><td>ORD-2402</td><td>Siti Aminah</td><td>Obat</td><td>Paracetamol 500 mg</td><td>${badge('Dispensed','green')}</td></tr>
          <tr><td>ORD-2403</td><td>Hendra Cipta</td><td>Radiologi</td><td>Rontgen Thorax</td><td>${badge('Menunggu','orange')}</td></tr>
          <tr><td>ORD-2404</td><td>Sarah Wijayanto</td><td>Rawat Inap</td><td>Bangsal Melati</td><td>${badge('Accepted','green')}</td></tr>
        </tbody>
      </table>
    </div>
  `;
}

function laboratoryPage() {
  return `
    <div class="page-header">
      <h1>Laboratory</h1>
      <p>Worklist pemeriksaan, penerimaan spesimen, input hasil, validasi dan otorisasi.</p>
    </div>

    <div class="grid grid-4">
      <div class="card metric-card"><label>Order Hari Ini</label><strong>42</strong><div class="metric-icon">⌁</div></div>
      <div class="card metric-card"><label>Menunggu Sampling</label><strong>8</strong><div class="metric-icon">○</div></div>
      <div class="card metric-card"><label>In Process</label><strong>11</strong><div class="metric-icon">…</div></div>
      <div class="card metric-card"><label>Critical Result</label><strong>1</strong><div class="metric-icon" style="background:#fff0f1;color:#c63c49;">!</div></div>
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="section-title">
        <div>
          <h2>Worklist Pemeriksaan</h2>
          <p>Order berasal dari CPOE dan unit pelayanan.</p>
        </div>
        <button class="btn btn-primary" data-modal="lab-result">Input Hasil</button>
      </div>

      <table>
        <thead><tr><th>Order</th><th>Pasien</th><th>Pemeriksaan</th><th>Spesimen</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <tr><td>LAB-2401</td><td>Budi Santoso</td><td>Darah Lengkap</td><td>EDTA</td><td>${badge('In Process','orange')}</td><td><button class="btn btn-primary btn-sm">Check-in</button></td></tr>
          <tr><td>LAB-2402</td><td>Siti Aminah</td><td>Gula Darah Sewaktu</td><td>Serum</td><td>${badge('Tervalidasi','green')}</td><td><button class="btn btn-secondary btn-sm">Lihat Hasil</button></td></tr>
          <tr><td>LAB-2403</td><td>Joko Widodo</td><td>Elektrolit</td><td>Serum</td><td>${badge('Menunggu','orange')}</td><td><button class="btn btn-primary btn-sm">Terima Spesimen</button></td></tr>
        </tbody>
      </table>
    </div>
  `;
}

function igdPage() {
  return `
    <div class="page-header">
      <h1>Pelayanan Gawat Darurat (IGD)</h1>
      <p>Triase, registrasi darurat, assessment klinis, observasi, CPOE cito, dan disposisi.</p>
    </div>

    <div class="grid grid-3">
      <div class="card metric-card"><label>Pasien IGD Hari Ini</label><strong>37</strong><div class="metric-icon">✚</div></div>
      <div class="card metric-card"><label>Zona Merah</label><strong>5</strong><div class="metric-icon" style="background:#fff0f1;color:#c63c49;">!</div></div>
      <div class="card metric-card"><label>Menunggu Dokter</label><strong>8</strong><div class="metric-icon" style="background:#fff6e8;color:#c47720;">⌛</div></div>
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="section-title">
        <div>
          <h2>Daftar Triase Hari Ini</h2>
          <p>Seluruh pasien yang telah ditriase beserta zona prioritasnya.</p>
        </div>
        <button class="btn btn-primary" data-modal="triage">+ Triase Pasien Baru</button>
      </div>

      <div class="toolbar">
        <input class="form-control" placeholder="Cari nama pasien">
        <select class="form-control">
          <option>Semua Zona</option>
          <option>Merah</option>
          <option>Kuning</option>
          <option>Hijau</option>
        </select>
      </div>

      <table>
        <thead><tr><th>Jam Triase</th><th>Pasien</th><th>Keluhan</th><th>ATS/ESI</th><th>Zona</th><th>Status Lanjutan</th></tr></thead>
        <tbody>
          <tr><td>10:40</td><td>Ny. Sari Melati</td><td>Sesak napas berat</td><td>ATS 2</td><td>${badge('Merah','red')}</td><td>${badge('Menunggu Registrasi','blue')}</td></tr>
          <tr><td>10:35</td><td>An. Bima (7 th)</td><td>Demam + kejang</td><td>ATS 2</td><td>${badge('Merah','red')}</td><td>${badge('Menunggu Registrasi','blue')}</td></tr>
          <tr><td>10:22</td><td>Tn. Joko Widodo</td><td>Luka robek tangan</td><td>ATS 4</td><td>${badge('Hijau','green')}</td><td>${badge('Menunggu Dokter','orange')}</td></tr>
          <tr><td>09:58</td><td>Ny. Ratna Sari</td><td>Nyeri perut hebat</td><td>ATS 3</td><td>${badge('Kuning','orange')}</td><td>${badge('Sedang Diperiksa','purple')}</td></tr>
          <tr><td>09:31</td><td>Tn. Bambang S.</td><td>Trauma kepala, GCS 7</td><td>ATS 1</td><td>${badge('Merah','red')}</td><td>${badge('Sedang Diperiksa','purple')}</td></tr>
        </tbody>
      </table>
    </div>

    <div class="grid grid-2" style="margin-top:16px;">
      <div class="card">
        <div class="section-title">
          <h2>Observasi & EWS</h2>
          <button class="btn btn-primary btn-sm">Simpan & Hitung Skor EWS</button>
        </div>
        <div class="form-grid">
          <div><label class="form-label">Tekanan Darah</label><input class="form-control" placeholder="88/54 mmHg"></div>
          <div><label class="form-label">Nadi</label><input class="form-control" placeholder="126 x/menit"></div>
          <div><label class="form-label">Laju Napas</label><input class="form-control" placeholder="28 x/menit"></div>
          <div><label class="form-label">Saturasi O₂</label><input class="form-control" placeholder="92%"></div>
        </div>
      </div>

      <div class="card">
        <div class="section-title"><h2>Disposisi Akhir Pasien</h2></div>
        <div class="form-grid">
          <div>
            <label class="form-label">Disposisi Akhir</label>
            <select class="form-control">
              <option>Pilih disposisi</option>
              <option>Rawat Inap</option>
              <option>Pulang</option>
              <option>Rujuk</option>
            </select>
          </div>
          <div>
            <label class="form-label">Kondisi Saat Disposisi</label>
            <select class="form-control">
              <option>Stabil</option>
              <option>Belum stabil</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  `;
}

function inpatientPage() {
  const beds = [
    ['A-101 / Bed 01', 'VIP • Melati', 'Tersedia', 'available'],
    ['A-102 / Bed 02', 'Kelas 1 • Melati', 'Tersedia', 'available'],
    ['A-103 / Bed 03', 'Kelas 1 • Melati', 'Terisi', 'occupied'],
    ['A-104 / Bed 04', 'Kelas 2 • Melati', 'Reserved', 'reserved'],
    ['B-201 / Bed 01', 'Kelas 2 • Anggrek', 'Tersedia', 'available'],
    ['B-202 / Bed 02', 'Kelas 2 • Anggrek', 'Proses Kebersihan', 'cleaning'],
    ['I-01 / Bed 01', 'ICU', 'Terisi', 'occupied'],
    ['I-02 / Bed 02', 'ICU', 'Tersedia', 'available']
  ];

  return `
    <div class="page-header">
      <h1>Pelayanan Rawat Inap</h1>
      <p>Admission, bed management, check-in, pelayanan, transfer, discharge, dan closing billing.</p>
    </div>

    <div class="card">
      <div class="section-title">
        <div>
          <h2>Master Bed — Status Saat Ini</h2>
          <p>Monitoring tempat tidur berdasarkan ruangan dan kelas.</p>
        </div>
        <button class="btn btn-primary" data-modal="admission">+ Admission Baru</button>
      </div>

      <div class="bed-grid">
        ${beds.map(([name, detail, status, cls]) => `
          <div class="bed-card ${cls}">
            <strong>${name}</strong>
            <small>${detail}</small>
            <div style="margin-top:7px;">${badge(status, cls === 'occupied' ? 'red' : cls === 'reserved' ? 'orange' : cls === 'cleaning' ? 'purple' : 'green')}</div>
            ${cls === 'available' ? '<button class="btn btn-success btn-sm">Pilih Bed</button>' : ''}
          </div>
        `).join('')}
      </div>
    </div>

    <div class="grid grid-2" style="margin-top:16px;">
      <div class="card">
        <div class="section-title"><h2>Admission & Registrasi</h2></div>
        <div class="info-strip">
          Alur: SPRI / indikasi rawat inap → registrasi admisi → verifikasi penjamin → alokasi bed → check-in.
        </div>
        <button class="btn btn-primary">Buka Form Admission</button>
      </div>

      <div class="card">
        <div class="section-title"><h2>Finalisasi Penjaminan</h2></div>
        <div class="form-grid">
          <div><label class="form-label">Jenis Penjamin</label><select class="form-control"><option>BPJS Kesehatan</option></select></div>
          <div><label class="form-label">No. SEP / Polis</label><input class="form-control" value="SEP-2026091200147"></div>
          <div><label class="form-label">Tanggungan Penjamin</label><input class="form-control" value="Rp 5.200.000"></div>
          <div><label class="form-label">Selisih / Iur Biaya</label><input class="form-control" value="Rp 300.000"></div>
        </div>
      </div>
    </div>
  `;
}

function nursingPage() {
  return `
    <div class="page-header">
      <h1>Asuhan Keperawatan (Nursing)</h1>
      <p>Asesmen awal, tanda vital & EWS, CPPT/SBAR, e-MAR, balans cairan, dan sinkronisasi obat.</p>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <div class="section-title"><h2>Form Asesmen Awal Keperawatan</h2></div>
        <div class="info-strip">Pasien: An. Rafi (9 th) • RM-000871 • Bed M-304</div>

        <div class="form-grid">
          <div>
            <label class="form-label">Skala Nyeri</label>
            <select class="form-control"><option>0 — tidak nyeri</option><option>1</option><option>2</option><option>3</option></select>
          </div>

          <div>
            <label class="form-label">Alat Ukur</label>
            <select class="form-control"><option>Wong-Baker FACES</option></select>
          </div>

          <div>
            <label class="form-label">Instrumen Risiko Jatuh</label>
            <select class="form-control"><option>Humpty Dumpty</option><option>Morse Fall Scale</option></select>
          </div>

          <div>
            <label class="form-label">Skor Risiko Jatuh</label>
            <input class="form-control" placeholder="cth. 13">
          </div>

          <div>
            <label class="form-label">Barthel Index</label>
            <input class="form-control" placeholder="0-100">
          </div>

          <div>
            <label class="form-label">Skrining Nutrisi</label>
            <select class="form-control"><option>Belum diisi</option><option>Normal</option><option>Risiko</option></select>
          </div>
        </div>

        <button class="btn btn-primary" style="margin-top:14px;">Simpan Asesmen</button>
      </div>

      <div class="card">
        <div class="section-title"><h2>Hasil Kalkulasi Skor Risiko</h2></div>
        <table>
          <tbody>
            <tr><td>Skala Nyeri</td><td>${badge('Belum dihitung','blue')}</td></tr>
            <tr><td>Risiko Jatuh</td><td>${badge('Belum dihitung','blue')}</td></tr>
            <tr><td>Barthel Index</td><td>${badge('Belum dihitung','blue')}</td></tr>
            <tr><td>Skrining Nutrisi</td><td>${badge('Belum dihitung','blue')}</td></tr>
          </tbody>
        </table>

        <div class="info-strip" style="margin-top:14px;">
          Sistem menghitung skor risiko otomatis dan hasil diteruskan ke Kepala Ruangan untuk validasi rencana asuhan.
        </div>
      </div>
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="section-title">
        <div>
          <h2>Order Masuk dari DPJP & Stok Depo Bangsal</h2>
          <p>Validasi ketersediaan obat dan sinkronisasi ke e-MAR.</p>
        </div>
      </div>

      <div class="grid grid-2">
        <table>
          <thead><tr><th>Jam</th><th>Pasien</th><th>Obat</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td>10:20</td><td>Tn. Adi Nugroho</td><td>Salbutamol nebule 2,5 mg</td><td>${badge('Menunggu Validasi','orange')}</td></tr>
            <tr><td>09:45</td><td>Ny. Sulastri</td><td>Norepinefrin drip</td><td>${badge('Menunggu Validasi','orange')}</td></tr>
            <tr><td>08:00</td><td>Tn. Adi Nugroho</td><td>Ceftriaxone 1 g IV</td><td>${badge('Tersinkron ke e-MAR','blue')}</td></tr>
          </tbody>
        </table>

        <table>
          <thead><tr><th>Obat</th><th>Stok</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td>Norepinefrin 4 mg/4 ml</td><td>2 ampul</td><td>${badge('Kritis','red')}</td></tr>
            <tr><td>Salbutamol nebule 2,5 mg</td><td>8 vial</td><td>${badge('Menipis','orange')}</td></tr>
            <tr><td>Ceftriaxone 1 g</td><td>24 vial</td><td>${badge('Aman','green')}</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function pharmacyPage() {
  const data = getData();

  return `
    <div class="page-header">
      <h1>Pengurusan Farmasi & Preskripsi</h1>
      <p>Kelola resep elektronik dan kemas kini status pemberian obat.</p>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <div class="section-title"><h2>Input Obat Baru</h2></div>

        <form id="pharmacyForm">
          <div class="form-group"><label class="form-label">Nama Pasien</label><input class="form-control" name="patient" placeholder="Contoh: Ahmad" required></div>
          <div class="form-group"><label class="form-label">Nama Obat</label><input class="form-control" name="drug" placeholder="Contoh: Paracetamol 500 mg" required></div>
          <div class="form-group"><label class="form-label">Dosis / Arahan</label><input class="form-control" name="dose" placeholder="Contoh: 3x sehari" required></div>
          <button class="btn btn-success" type="submit" style="width:100%;">+ Tambah Preskripsi</button>
        </form>
      </div>

      <div class="card">
        <div class="section-title"><h2>Daftar Preskripsi Aktif</h2></div>

        <table>
          <thead><tr><th>Pasien</th><th>Butiran Obat</th><th>Status</th><th>Tindakan</th></tr></thead>
          <tbody>
            ${data.prescriptions.map((row, index) => `
              <tr>
                <td><small>${row.id}</small><br><b>${row.patient}</b></td>
                <td><b>${row.drug}</b><br><small>${row.dose}</small></td>
                <td>${badge(row.status, row.status === 'Selesai' ? 'green' : 'orange')}</td>
                <td>
                  ${row.status !== 'Selesai'
                    ? `<button class="btn btn-success btn-sm" data-finish-prescription="${index}">Tanda Selesai</button>`
                    : '<span style="color:#20a76b;font-size:11px;">✓ Diberikan</span>'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function radiologyPage() {
  const data = getData();

  return `
    <div class="page-header">
      <h1>Pemeriksaan Radiologi</h1>
      <p>Antrean pemeriksaan radiologi dan unggah hasil ke PACS.</p>
    </div>

    <div class="card">
      <div class="section-title">
        <div>
          <h2>Antrean Radiologi</h2>
          <p>Daftar order radiologi aktif.</p>
        </div>
        <button class="btn btn-purple" data-modal="radiology-order">+ Tambah Pasien</button>
      </div>

      <table>
        <thead><tr><th>No. Pesanan</th><th>Nama Pasien</th><th>Jenis Pemeriksaan</th><th>Status</th><th>Tindakan</th></tr></thead>
        <tbody>
          ${data.radiology.map((row, index) => `
            <tr>
              <td>${row.no}</td>
              <td><b>${row.patient}</b></td>
              <td>${row.exam}</td>
              <td>${badge(row.status, row.status.includes('Selesai') ? 'blue' : 'orange')}</td>
              <td>
                ${row.status.includes('Selesai')
                  ? '<span style="color:#98a2b3;font-size:11px;">Keputusan dimuat naik</span>'
                  : `<button class="btn btn-purple btn-sm" data-finish-rad="${index}">Upload Keputusan</button>`}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function inventoryPage() {
  const data = getData();

  return `
    <div class="page-header">
      <h1>Pengurusan Inventori Medis & Non-Medis</h1>
      <p>Tambah item, pantau stok, kekurangan stok, dan buat permintaan barang beserta lokasi.</p>
    </div>

    <div class="grid grid-3">
      <div class="card">
        <div class="section-title"><h2>Tambah Item Baru</h2></div>
        <form id="inventoryForm">
          <div class="form-group"><label class="form-label">Kategori Item</label><select class="form-control" name="category"><option>Medis</option><option>Non-Medis</option></select></div>
          <div class="form-group"><label class="form-label">Nama Barang / Obat</label><input class="form-control" name="item" placeholder="Contoh: Paracetamol / Kertas A4" required></div>
          <div class="form-group"><label class="form-label">Lokasi / Depo Penyimpanan</label><input class="form-control" name="location" placeholder="Gudang Utama / Depo Farmasi" required></div>
          <div class="form-group"><label class="form-label">Jumlah Stok Awal</label><input class="form-control" name="stock" type="number" value="100" min="0"></div>
          <button class="btn btn-primary" type="submit" style="width:100%;">Simpan ke Inventori</button>
        </form>
      </div>

      <div class="card">
        <div class="section-title"><h2>Request Barang & Lokasi</h2></div>
        <div class="form-group"><label class="form-label">Pilih Barang</label><select class="form-control">${data.inventory.map(item => `<option>${item.item} (Stok: ${item.stock})</option>`).join('')}</select></div>
        <div class="form-group"><label class="form-label">Kuantitas yang Diminta</label><input class="form-control" type="number" value="20"></div>
        <div class="form-group"><label class="form-label">Lokasi / Unit Pemohon</label><input class="form-control" placeholder="Contoh: Poli Anak / Unit IGD"></div>
        <button class="btn btn-warning" style="width:100%;">↪ Hantar Request</button>
      </div>

      <div class="dark-card">
        <h3 style="margin-top:0;">Status Gudang</h3>
        <p>Pemantauan logistik medik dan non-medik secara bersepadu.</p>
        <div style="height:54px;"></div>
        <div class="dark-stat"><span>Total Jenis Item</span><strong>${data.inventory.length}</strong></div>
        <div class="dark-stat"><span>Request Pending</span><strong style="color:#ff8d56;">3</strong></div>
      </div>
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="section-title"><h2>Update Stok dan Lokasi</h2></div>
      <table>
        <thead><tr><th>Kode</th><th>Nama Barang</th><th>Kategori</th><th>Lokasi / Depo</th><th>Stok</th></tr></thead>
        <tbody>
          ${data.inventory.map(item => `<tr><td>${item.code}</td><td>${item.item}</td><td>${item.category}</td><td>${item.location}</td><td><b>${item.stock}</b></td></tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function billingPage() {
  const data = getData();
  const unpaid = data.billing.filter(row => row.status !== 'Lunas').length;
  const revenue = data.billing.filter(row => row.status === 'Lunas').reduce((sum, row) => sum + Number(row.total), 0);

  return `
    <div class="page-header">
      <h1>Pengelolaan Pembayaran & Kasir (Billing)</h1>
      <p>Memastikan jumlah tagihan pasien, metode pembayaran, cetak struk, dan status pelunasan.</p>
    </div>

    <div class="grid grid-3">
      <div class="card metric-card"><label>Total Tagihan Belum Lunas</label><strong>${unpaid} Pasien</strong><div class="metric-icon" style="background:#fff1ea;color:#df6a21;">▧</div></div>
      <div class="card metric-card"><label>Total Pendapatan Hari Ini</label><strong>${money(revenue)}</strong><div class="metric-icon" style="background:#e9fbf2;color:#20a76b;">Rp</div></div>
      <div class="card" style="display:grid;place-items:center;"><button class="btn btn-primary" data-modal="invoice">+ Buat Tagihan Pasien Baru</button></div>
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="section-title"><h2>Daftar Tagihan & Status Pembayaran</h2></div>

      <table>
        <thead><tr><th>No. Tagihan / RM</th><th>Nama Pasien</th><th>Rincian Layanan</th><th>Total Biaya</th><th>Metode</th><th>Status</th><th>Aksi Kasir</th></tr></thead>
        <tbody>
          ${data.billing.map((row, index) => `
            <tr>
              <td>${row.no}<br><small>${row.rm}</small></td>
              <td><b>${row.patient}</b></td>
              <td>${row.service}</td>
              <td><b>${money(row.total)}</b></td>
              <td>${row.method}</td>
              <td>${badge(row.status, row.status === 'Lunas' ? 'green' : 'orange')}</td>
              <td>
                ${row.status === 'Lunas'
                  ? `<button class="btn btn-secondary btn-sm" data-receipt="${index}">Cetak Struk</button>`
                  : `<button class="btn btn-primary btn-sm" data-pay="${index}">Bayar & Proses</button>`}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function reportingPage() {
  return `
    <div class="page-header">
      <h1>Laporan Operasional</h1>
      <p>Ringkasan indikator operasional rumah sakit.</p>
    </div>

    <div class="grid grid-5">
      <div class="card metric-card"><label>Total Kunjungan</label><strong>4.286</strong><small>September 2026</small></div>
      <div class="card metric-card"><label>Pendapatan</label><strong>2,4 M</strong><small>bulan berjalan</small></div>
      <div class="card metric-card"><label>BOR</label><strong>72%</strong><small>rawat inap</small></div>
      <div class="card metric-card"><label>LOS</label><strong>4,1</strong><small>hari</small></div>
      <div class="card metric-card"><label>Kasus Terbanyak</label><strong>HT</strong><small>Hipertensi</small></div>
    </div>

    <div class="grid grid-2" style="margin-top:16px;">
      <div class="card">
        <div class="section-title"><h2>BOR & LOS</h2></div>
        <table>
          <thead><tr><th>Ruangan</th><th>Tempat Tidur</th><th>BOR</th><th>LOS</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td>Anggrek</td><td>30</td><td>78%</td><td>4,2 hari</td><td>${badge('Normal','green')}</td></tr>
            <tr><td>Mawar</td><td>24</td><td>86%</td><td>5,1 hari</td><td>${badge('Tinggi','orange')}</td></tr>
            <tr><td>Melati</td><td>20</td><td>61%</td><td>3,5 hari</td><td>${badge('Normal','green')}</td></tr>
          </tbody>
        </table>
      </div>

      <div class="card">
        <div class="section-title"><h2>Ringkasan Kunjungan</h2></div>
        <div class="kpi-row">
          <div class="mini-kpi"><span>Rawat Jalan</span><b>2.891</b></div>
          <div class="mini-kpi"><span>IGD</span><b>795</b></div>
          <div class="mini-kpi"><span>Rawat Inap</span><b>600</b></div>
        </div>
      </div>
    </div>
  `;
}

function monthlyPage() {
  return `
    <div class="page-header">
      <h1>Rekap Bulan September 2026</h1>
      <p>Laporan bulanan untuk proses koreksi, cetak, distribusi, dan arsip.</p>
    </div>

    <div class="info-strip">
      <b>Status laporan: Draft / siap koreksi.</b><br>
      Laporan dapat ditinjau sebelum diserahkan kepada Bidang Pelayanan Medis.
    </div>

    <div class="grid grid-3">
      ${[
        ['Rekap Kunjungan', 'Rekap kunjungan pasien per unit pelayanan.'],
        ['Indikator Rawat Inap', 'BOR, LOS, TOI, dan indikator pelayanan rawat inap.'],
        ['Rekap Pendapatan', 'Ringkasan pendapatan pelayanan.']
      ].map(([title, desc], index) => `
        <div class="card">
          <div class="tile-icon">${index === 2 ? 'Rp' : index === 1 ? '▣' : '▤'}</div>
          <h3 style="font-size:14px;">${title}</h3>
          <p style="font-size:11px;color:#667085;">${desc}</p>
          <button class="btn btn-secondary btn-sm">Buka Laporan</button>
          ${index === 0 ? '<button class="btn btn-secondary btn-sm">Ekspor CSV</button>' : ''}
        </div>
      `).join('')}
    </div>

    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px;">
      <button class="btn btn-secondary">Cetak Rekap</button>
      <button class="btn btn-primary">Serahkan untuk Koreksi</button>
    </div>
  `;
}

function auditPage() {
  const data = getData();

  return `
    <div class="page-header">
      <h1>Audit Log</h1>
      <p>Jejak aktivitas pengguna pada sistem.</p>
    </div>

    <div class="card">
      <table>
        <thead><tr><th>Waktu</th><th>Pengguna</th><th>Aktivitas</th><th>Modul</th></tr></thead>
        <tbody>
          ${data.audit.map(row => `<tr><td>${row.time}</td><td>${row.user}</td><td>${row.action}</td><td>${badge(row.module,'blue')}</td></tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function bindPageActions(user, page) {
  document.querySelectorAll('[data-open-page]').forEach(item => {
    item.addEventListener('click', () => {
      const target = item.dataset.openPage;
      if (!allowed(user, target)) {
        toast('Akses ditolak untuk role ini.');
        return;
      }
      renderApp(user, target);
    });
  });

  document.querySelectorAll('[data-modal]').forEach(button => {
    button.addEventListener('click', () => {
      openModal(button.dataset.modal, user);
    });
  });

  if (page === 'pharmacy') {
    const form = document.getElementById('pharmacyForm');

    form?.addEventListener('submit', event => {
      event.preventDefault();

      const data = getData();
      const formData = new FormData(form);

      data.prescriptions.unshift({
        id: 'RSP-' + Math.floor(200 + Math.random() * 700),
        patient: formData.get('patient'),
        drug: formData.get('drug'),
        dose: formData.get('dose'),
        status: 'Diproses'
      });

      saveData(data);
      toast('Preskripsi ditambahkan.');
      renderApp(user, 'pharmacy');
    });

    document.querySelectorAll('[data-finish-prescription]').forEach(button => {
      button.addEventListener('click', () => {
        const data = getData();
        const index = Number(button.dataset.finishPrescription);
        data.prescriptions[index].status = 'Selesai';
        saveData(data);
        toast('Status preskripsi diperbarui.');
        renderApp(user, 'pharmacy');
      });
    });
  }

  if (page === 'radiology') {
    document.querySelectorAll('[data-finish-rad]').forEach(button => {
      button.addEventListener('click', () => {
        const data = getData();
        const index = Number(button.dataset.finishRad);
        data.radiology[index].status = 'Selesai (PACS)';
        saveData(data);
        toast('Hasil radiologi ditandai selesai dan tersinkron ke PACS.');
        renderApp(user, 'radiology');
      });
    });
  }

  if (page === 'inventory') {
    const form = document.getElementById('inventoryForm');

    form?.addEventListener('submit', event => {
      event.preventDefault();

      const data = getData();
      const formData = new FormData(form);

      data.inventory.push({
        code: 'INV-' + String(data.inventory.length + 1).padStart(3, '0'),
        item: formData.get('item'),
        category: formData.get('category'),
        location: formData.get('location'),
        stock: Number(formData.get('stock') || 0)
      });

      saveData(data);
      toast('Item berhasil disimpan ke inventori.');
      renderApp(user, 'inventory');
    });
  }

  if (page === 'billing') {
    document.querySelectorAll('[data-pay]').forEach(button => {
      button.addEventListener('click', () => {
        const data = getData();
        const index = Number(button.dataset.pay);
        openPaymentModal(index, user);
      });
    });

    document.querySelectorAll('[data-receipt]').forEach(button => {
      button.addEventListener('click', () => {
        const index = Number(button.dataset.receipt);
        openReceipt(index);
      });
    });
  }
}

function openModal(type, user) {
  const templates = {
    'user-request': {
      title: 'Buat Permintaan',
      body: `
        <div class="form-grid">
          <div><label class="form-label">ID Permintaan</label><input class="form-control" value="REQ-005"></div>
          <div><label class="form-label">Nama Pemohon</label><input class="form-control" placeholder="Nama pemohon"></div>
          <div><label class="form-label">Unit</label><select class="form-control"><option>IGD</option><option>Rawat Inap</option><option>Laboratorium</option></select></div>
          <div><label class="form-label">Jenis Permintaan</label><select class="form-control"><option>Akun Baru</option><option>Perubahan Role</option><option>Reset Akses</option></select></div>
          <div class="full"><label class="form-label">Catatan</label><textarea class="form-control"></textarea></div>
        </div>
      `
    },

    doctor: {
      title: 'Tambah Data Dokter',
      body: `
        <div class="form-grid">
          <div><label class="form-label">Kode</label><input class="form-control" value="DR005"></div>
          <div><label class="form-label">Nama Dokter</label><input class="form-control"></div>
          <div><label class="form-label">Spesialisasi</label><select class="form-control"><option>Umum</option><option>Penyakit Dalam</option><option>Anak</option></select></div>
          <div><label class="form-label">Poli</label><select class="form-control"><option>Poli Umum</option><option>Poli Anak</option></select></div>
        </div>
      `
    },

    unit: {
      title: 'Tambah Data Poli',
      body: `
        <div class="form-grid">
          <div><label class="form-label">Kode</label><input class="form-control" value="PL004"></div>
          <div><label class="form-label">Nama Poli</label><input class="form-control"></div>
        </div>
      `
    },

    room: {
      title: 'Tambah Data Ruangan',
      body: `
        <div class="form-grid">
          <div><label class="form-label">Kode</label><input class="form-control" value="RM004"></div>
          <div><label class="form-label">Nama Ruangan</label><input class="form-control" placeholder="Mawar"></div>
          <div><label class="form-label">Kelas</label><select class="form-control"><option>VIP</option><option>VVIP</option><option>Kelas 1</option><option>Kelas 2</option><option>ICU</option><option>HCU</option></select></div>
          <div><label class="form-label">Kapasitas</label><input class="form-control" type="number" value="20"></div>
        </div>
      `
    },

    soap: {
      title: 'Tambah SOAP / CPPT',
      body: `
        <div class="form-grid">
          <div class="full"><label class="form-label">Subjective</label><textarea class="form-control"></textarea></div>
          <div class="full"><label class="form-label">Objective</label><textarea class="form-control"></textarea></div>
          <div class="full"><label class="form-label">Assessment</label><textarea class="form-control"></textarea></div>
          <div class="full"><label class="form-label">Plan</label><textarea class="form-control"></textarea></div>
        </div>
      `
    },

    'lab-order': {
      title: 'Order Pemeriksaan Laboratorium',
      body: orderForm('Laboratorium')
    },

    'med-order': {
      title: 'Medication Order',
      body: orderForm('Obat')
    },

    'rad-order': {
      title: 'Order Radiologi',
      body: orderForm('Radiologi')
    },

    'admission-order': {
      title: 'Admission Order',
      body: orderForm('Rawat Inap')
    },

    'lab-result': {
      title: 'Input Hasil Laboratorium',
      body: `
        <div class="form-grid">
          <div><label class="form-label">Order</label><input class="form-control" value="LAB-2401"></div>
          <div><label class="form-label">Pemeriksaan</label><input class="form-control" value="Darah Lengkap"></div>
          <div><label class="form-label">Hb</label><input class="form-control" placeholder="g/dL"></div>
          <div><label class="form-label">Leukosit</label><input class="form-control" placeholder="/µL"></div>
          <div class="full"><label class="form-label">Catatan</label><textarea class="form-control"></textarea></div>
        </div>
      `
    },

    triage: {
      title: 'Triase Pasien Baru',
      body: `
        <div class="form-grid">
          <div><label class="form-label">Nama Pasien</label><input class="form-control"></div>
          <div><label class="form-label">Keluhan Utama</label><input class="form-control"></div>
          <div><label class="form-label">ATS / ESI</label><select class="form-control"><option>ATS 1</option><option>ATS 2</option><option>ATS 3</option><option>ATS 4</option><option>ATS 5</option></select></div>
          <div><label class="form-label">Zona</label><select class="form-control"><option>Merah</option><option>Kuning</option><option>Hijau</option></select></div>
        </div>
      `
    },

    admission: {
      title: 'Admission Rawat Inap',
      body: `
        <div class="form-grid">
          <div><label class="form-label">No. RM</label><input class="form-control" placeholder="RM-"></div>
          <div><label class="form-label">Unit Tujuan</label><select class="form-control"><option>Melati</option><option>Anggrek</option><option>Mawar</option></select></div>
          <div><label class="form-label">Penjamin</label><select class="form-control"><option>BPJS Kesehatan</option><option>Umum</option></select></div>
          <div><label class="form-label">Prioritas</label><select class="form-control"><option>Rutin</option><option>Cito</option></select></div>
        </div>
      `
    },

    'radiology-order': {
      title: 'Tambah Pasien Radiologi',
      body: `
        <div class="form-grid">
          <div><label class="form-label">Nama Pasien</label><input class="form-control"></div>
          <div><label class="form-label">Pemeriksaan</label><select class="form-control"><option>Rontgen Thorax</option><option>USG Abdomen</option><option>CT Scan Abdomen</option><option>MRI Kepala</option></select></div>
        </div>
      `
    },

    invoice: {
      title: 'Buat Tagihan Baru',
      body: `
        <div class="form-group"><label class="form-label">Nama Pasien</label><input class="form-control" id="invoicePatient"></div>
        <div class="form-group"><label class="form-label">Rincian Layanan / Poli</label><input class="form-control" id="invoiceService"></div>
        <div class="form-group"><label class="form-label">Total Biaya (Rp)</label><input class="form-control" type="number" id="invoiceTotal"></div>
      `
    }
  };

  const config = templates[type];
  if (!config) return;

  showModal(config.title, config.body, () => {
    if (type === 'invoice') {
      const data = getData();
      data.billing.push({
        no: 'BL-' + String(data.billing.length + 1).padStart(3, '0'),
        rm: 'RM-' + String(2000 + data.billing.length),
        patient: document.getElementById('invoicePatient').value || 'Pasien Baru',
        service: document.getElementById('invoiceService').value || 'Layanan',
        total: Number(document.getElementById('invoiceTotal').value || 0),
        method: 'Belum Dipilih',
        status: 'Belum Lunas'
      });
      saveData(data);
      toast('Tagihan baru dibuat.');
      renderApp(user, 'billing');
      return;
    }

    toast('Data berhasil disimpan pada prototype.');
  });
}

function orderForm(kind) {
  return `
    <div class="form-grid">
      <div><label class="form-label">Pasien</label><input class="form-control" value="Budi Santoso • RM-000123"></div>
      <div><label class="form-label">Jenis Order</label><input class="form-control" value="${kind}"></div>
      <div><label class="form-label">Prioritas</label><select class="form-control"><option>Rutin</option><option>Cito</option></select></div>
      <div><label class="form-label">Dokter Peminta</label><input class="form-control" value="dr. Andi Pratama"></div>
      <div class="full"><label class="form-label">Detail / Instruksi</label><textarea class="form-control" placeholder="Masukkan detail order..."></textarea></div>
    </div>
  `;
}

function showModal(title, body, onSave) {
  const container = document.createElement('div');
  container.className = 'modal-backdrop';
  container.innerHTML = `
    <div class="modal">
      <div class="modal-head">
        <h3>${title}</h3>
        <button class="close-x" data-close-modal>×</button>
      </div>
      <div class="modal-body">
        ${body}
        <div class="modal-actions">
          <button class="btn btn-secondary" data-close-modal>Batal</button>
          <button class="btn btn-primary" id="modalSave">Simpan</button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  container.querySelectorAll('[data-close-modal]').forEach(button => {
    button.addEventListener('click', () => container.remove());
  });

  container.addEventListener('click', event => {
    if (event.target === container) container.remove();
  });

  container.querySelector('#modalSave').addEventListener('click', () => {
    onSave?.();
    container.remove();
  });
}

function openPaymentModal(index, user) {
  const data = getData();
  const row = data.billing[index];

  showModal(
    'Proses Pembayaran Pasien',
    `
      <div class="info-strip">
        <b>No. Tagihan:</b> ${row.no} (${row.rm})<br>
        <b>Nama Pasien:</b> ${row.patient}<br>
        <b>Rincian Layanan:</b> ${row.service}<br>
        <b>Total Tagihan:</b> ${money(row.total)}
      </div>

      <div class="form-group">
        <label class="form-label">Pilih Metode Pembayaran</label>
        <select class="form-control" id="paymentMethod">
          <option>Transfer Bank</option>
          <option>QRIS / E-Wallet</option>
          <option>BPJS Kesehatan</option>
          <option>Tunai</option>
        </select>
      </div>
    `,
    () => {
      const method = document.getElementById('paymentMethod').value;
      const current = getData();
      current.billing[index].method = method;
      current.billing[index].status = 'Lunas';
      saveData(current);
      toast('Pembayaran selesai dan status diperbarui.');
      renderApp(user, 'billing');
    }
  );
}

function openReceipt(index) {
  const row = getData().billing[index];

  showModal(
    'Struk Pembayaran / Invoice RS',
    `
      <div style="line-height:1.8;font-size:12px;">
        <b>RS PERMATA ASRI</b><br>
        No. Tagihan: ${row.no}<br>
        No. RM: ${row.rm}<br>
        Nama Pasien: ${row.patient}<br>
        Rincian: ${row.service}<br>
        Total Biaya: <b>${money(row.total)}</b><br>
        Metode Bayar: ${row.method}<br>
        Status: LUNAS
      </div>
    `,
    () => {
      toast('Struk siap dicetak.');
    }
  );
}

function toast(message) {
  document.querySelector('.toast')?.remove();

  const item = document.createElement('div');
  item.className = 'toast';
  item.textContent = message;
  document.body.appendChild(item);

  setTimeout(() => item.remove(), 2400);
}

function boot() {
  const session = getSession();

  if (session) {
    renderApp(session, 'dashboard');
  } else {
    renderLogin();
  }
}

document.addEventListener('DOMContentLoaded', boot);
